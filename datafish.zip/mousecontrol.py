import pyautogui
import time

time.sleep(1)
pyautogui.hotkey('win', 'tab')
time.sleep(1)
pyautogui.click(100, 70)
pyautogui.click(300, 90)
time.sleep(1)
pyautogui.hotkey('win', 'tab')
time.sleep(1)
pyautogui.click(300, 90)
# pyautogui.click(100, 70)
