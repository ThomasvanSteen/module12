import os
import pyautogui
import time

import subprocess
subprocess.Popen('C:\\Windows\\System32\\notepad.exe')

time.sleep(2)
pyautogui.write('Hello There', interval = 0.1)
pyautogui.press('enter')
pyautogui.write('im your device', interval = 0.1)
pyautogui.press('enter')
pyautogui.write('and i know your search history', interval = 0.1)
pyautogui.press('enter')
pyautogui.write('even your private browser history', interval = 0.1)